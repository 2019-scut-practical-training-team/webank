package org.fisco.bcos.Service.Interface;

import com.alibaba.fastjson.JSONObject;

public interface ICheckService {
    public JSONObject check(String address);
}
