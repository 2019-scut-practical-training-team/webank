package org.fisco.bcos.Service.Interface;

import com.alibaba.fastjson.JSONObject;

public interface IPetService {
    public JSONObject pets();
}
